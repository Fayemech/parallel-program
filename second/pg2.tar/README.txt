    After decompress it, goes in to the file folder and run make. I already test it, makefile works well. If it doesn't work, it can also be done with "cc -fopenmp kleo.c -o kleo -lm -DVERBOSE" then ./kleo  will work.

    Use time ./kleo will be able to see the time.
